<?php


include("../model/database.php");


$registrationError = "";

if(isset($_POST['Submit'])){
    $connection = new databaseConnection();
    $connectionObject = $connection->openCon();
    $registerUser = $connection->userRegistration($connectionObject, "employee", $_REQUEST["fname"], $_REQUEST["lname"], $_REQUEST["age"], $_REQUEST["designation"] , $_REQUEST["planguage"],$_REQUEST["email"], $_REQUEST["password"], $_REQUEST["picture"]);
    if($registerUser){
        $registrationError = 'Registration Successful'; 
    }
    else{
        $registrationError = 'Registration Unsuccessful';
    }



    $connection->closeConnection($connectionObject);
}





if(empty($_POST["fname"])){
    echo" The First Name is empty" .$_POST["fname"]."<br>";
}
else{
    echo" Your First Name is " .$_POST["fname"]."<br>";
}

if(is_numeric($_POST["lname"])){
    echo" The Last Name is empty" .$_POST["lname"]."<br>";
}
else{
    echo" Your Last Name is " .$_POST["lname"]."<br>";
}


if(isset($_POST["Java"]) || isset($_POST["PHP"]) || isset($_POST["C++"])){
    echo"You have selected checkbox"."<br>";
}
else{
    echo"You have not selected any Checkbox"."<br>";
}


if(empty($_POST["email"])){
    echo" The Email is empty" .$_POST["email"]."<br>";
}
else{
    echo" Your Email is ".$_POST["email"]."<br>";
}

if(strlen($_POST["password"])<6){
    echo" The Password can not be less than 6 characters!"."<br>";
}
else{
    echo" Your Password is Correct."."<br>";
}


?>